import 'package:flutter/material.dart';

class AppColors {
  static const Color grey = Color(0xff515151);
  static const Color black = Color(0xff000000);
  static const Color white = Color(0xffe4eaef);
  static const Color primaryColor = Color(0xff5DB1DF);
}
