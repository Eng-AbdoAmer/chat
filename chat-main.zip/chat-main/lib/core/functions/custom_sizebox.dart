import 'package:flutter/material.dart';

space(double h, double w) {
  return SizedBox(
    height: 0 + h,
    width: 0 + w,
  );
}
