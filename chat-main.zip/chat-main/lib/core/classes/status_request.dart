enum StatusRequest {
  loading,
  success,
  failure,
  serverFailure,
  serverException,
  offline,
}
